#include <iostream>
#include "SetAsArray.h"

using std::cout;
using std::endl;

int main()
{
    // Utwórz zbiory A,B,C i D (zbiór uniwersalny rozmiar 10)
    int size = 10;
    SetAsArray A(size), B(size), C(size), D(size);

    for (int i = 0; i < size; i++)
    {
        // Do zbioru A wstaw elementy parzyste
        // Do zbioru B wstaw elementy nieparzyste
        if (i % 2)
        {
            A.Insert(i);
        }
        else B.Insert(i);

        
    }

    C=A+B;
    D=C-B;
    cout << "Zbior A:" << endl;
    A.Wypisz();
    cout << "Zbior B:" << endl;
    B.Wypisz();
    cout << "Zbior C:" << endl;
    C.Wypisz();
    cout << "Zbior D:" << endl;
    D.Wypisz();

    // sprawdź, czy:
    // 	 "D==A" 
    //   "D<=A" 
    // 	 "C==B" 
    // 	 "B<=C"
    cout << "Wynik operacji D==A: " << ((D == A) ? "true" : "false") << endl;
    cout << "Wynik operacji D<=A: " << ((D <= A) ? "true" : "false") << endl;
    cout << "Wynik operacji C==B: " << ((C == B) ? "true" : "false") << endl;
    cout << "Wynik operacji B<=C: " << ((B <= C) ? "true" : "false") << endl;


    // Do zbioru A wstaw elementy wartość 1

    for (int i = 0; i < size; i++)
    {
        A.Insert(i);
    }
    
    cout << "Zbior A:" << endl;
    A.Wypisz();
    
    // sprawdź, czy: 
    // 	 "D==A" 
    //   "D<=A"
    cout << "Wynik operacji D==A: " << ((D == A) ? "true" : "false") << endl;
    cout << "Wynik operacji D<=A: " << ((D <= A) ? "true" : "false") << endl;

    return 0;
}

