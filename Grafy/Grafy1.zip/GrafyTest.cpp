#include <iostream>
#include "Edge.h"
#include "Vertex.h"
#include "GraphAsMatrix.h"

using std::cout;
using std::endl;

int main()
{
  // Utworz Graf skierowany zlozony z 10 wierzcholkow
  // Wypisz, ile jest wierzcholkow
  // Wypisz, ile jest krawedzi 
  GraphAsMatrix Graf1(10,true);
  cout << "Liczba wierzcholkow: " << Graf1.NumberOfVertices() << endl;
  cout << "Liczba krawedzi: " << Graf1.NumberOfEdges() << endl;
  cout << endl;

  Vertex* v1 = Graf1.SelectVertex(2);
  // Wypisz unikalny Numer v
  // Nadaj v wagę unikalnyNumer*UniklanyNumer;
  // Wypisz wage v
  cout << "Unikalny Numer v: " << v1->Number() << endl;
  v1->weight = 7 * 7;
  cout << "Unikalna waga v: " << v1->weight << endl;
  cout << endl;

  Graf1.AddEdge(1,2);
  Graf1.AddEdge(1,2);
  Graf1.AddEdge(2,3);
  Graf1.AddEdge(3,4);
  Graf1.AddEdge(9,9);

  // Wypisz, ile jest wierzcholkow
  // Wypisz, ile jest krawedzi
  // Wypisz, czy istnieje krawedz (1,1)
  // Wypisz, czy istnieje krawedz (1,2)
  // Wypisz, czy istnieje krawedz (2,1)

  cout << "Liczba wierzcholkow: " << Graf1.NumberOfVertices() << endl;
  cout << "Liczba krawedzi: " << Graf1.NumberOfEdges() << endl;
  cout << "Czy istnieje krawedz (1,1): " << (Graf1.IsEdge(1,1) ? "Tak" : "Nie") << endl;
  cout << "Czy istnieje krawedz (1,2): " << (Graf1.IsEdge(1,2) ? "Tak" : "Nie") << endl;
  cout << "Czy istnieje krawedz (2,1): " << (Graf1.IsEdge(2,1) ? "Tak" : "Nie") << endl;
  cout << endl;

  cout << "Krawedz (1,2)" << endl;
  Edge* e1 = Graf1.SelectEdge(1,2);
  // Wypisz V0 dla e
  // Wypisz V1 dla e
  cout << "v0 dla e: " << e1->V0()->Number() << endl;
  cout << "v1 dla e: " << e1->V1()->Number() << endl;

  // Wypisz sasiada (V0) dla e - test metody Mate
  // Wypisz sasiada (V1) dla e - test metody Mate
  cout << "Sasiad (v0) dla e: " << e1->Mate(e1->V0())->Number() << endl;
  cout << "Sasiad (v1) dla e: " << e1->Mate(e1->V1())->Number() << endl;

  // Nadaj krawedzi e wagę V0+V1
  // Wypisz wage krawedzi e
  e1->weight = e1->V0()->Number() + e1->V1()->Number();
  cout << "Waga krawedzi e: " << e1->weight << endl;
  cout << endl;

  // Dla kolejnych krawedzi Graf1u powtorz ostatnie 7 krokow (e=SelectEdge(2,3),…)
  cout << "Krawedz (2,3)" << endl;
  Edge* e2 = Graf1.SelectEdge(2,3);

  cout << "v0 dla e: " << e2->V0()->Number() << endl;
  cout << "v1 dla e: " << e2->V1()->Number() << endl;

  cout << "Sasiad (v0) dla e: " << e2->Mate(e2->V0())->Number() << endl;
  cout << "Sasiad (v1) dla e: " << e2->Mate(e2->V1())->Number() << endl;

  e2->weight = e2->V0()->Number() + e2->V1()->Number();
  cout << "Waga krawedzi e: " << e2->weight << endl;
  cout << endl;

  // Krawedz (3,4)
  cout << "Krawedz (3,4)" << endl;
  Edge* e3 = Graf1.SelectEdge(3,4);

  cout << "v0 dla e: " << e3->V0()->Number() << endl;
  cout << "v1 dla e: " << e3->V1()->Number() << endl;

  cout << "Sasiad (v0) dla e: " << e3->Mate(e3->V0())->Number() << endl;
  cout << "Sasiad (v1) dla e: " << e3->Mate(e3->V1())->Number() << endl;

  e3->weight = e3->V0()->Number() + e3->V1()->Number();
  cout << "Waga krawedzi e: " << e3->weight << endl;
  cout << endl;

  // Krawedz (9,9)
  cout << "Krawedz (9,9)" << endl;
  Edge* e4 = Graf1.SelectEdge(9,9);

  cout << "v0 dla e: " << e4->V0()->Number() << endl;
  cout << "v1 dla e: " << e4->V1()->Number() << endl;

  cout << "Sasiad (v0) dla e: " << e4->Mate(e4->V0())->Number() << endl;
  cout << "Sasiad (v1) dla e: " << e4->Mate(e4->V1())->Number() << endl;

  e4->weight = e4->V0()->Number() + e4->V1()->Number();
  cout << "Waga krawedzi e: " << e4->weight << endl;
  cout << endl;

  // Testy prosze powtorzyc tworzac Graf nieskierowany 

  cout << "—————— DLA GRAFU NIESKIEROWANEGO ——————" << endl;
  GraphAsMatrix Graf2(10,false);
  cout << "Liczba wierzcholkow: " << Graf2.NumberOfVertices() << endl;
  cout << "Liczba krawedzi: " << Graf2.NumberOfEdges() << endl;
  cout << endl;

  Vertex* v2 = Graf2.SelectVertex(2);

  cout << "Unikalny Numer v: " << v2->Number() << endl;
  v2->weight = 7 * 7;
  cout << "Unikalna waga v: " << v2->weight << endl;
  cout << endl;

  Graf2.AddEdge(1,2);
  Graf2.AddEdge(1,2);
  Graf2.AddEdge(2,3);
  Graf2.AddEdge(3,4);
  Graf2.AddEdge(9,9);

  cout << "Liczba wierzcholkow: " << Graf2.NumberOfVertices() << endl;
  cout << "Liczba krawedzi: " << Graf2.NumberOfEdges() << endl;
  cout << "Czy istnieje krawedz (1,1): " << (Graf2.IsEdge(1,1) ? "Tak" : "Nie") << endl;
  cout << "Czy istnieje krawedz (1,2): " << (Graf2.IsEdge(1,2) ? "Tak" : "Nie") << endl;
  cout << "Czy istnieje krawedz (2,1): " << (Graf2.IsEdge(2,1) ? "Tak" : "Nie") << endl;
  cout << endl;

  cout << "Krawedz (1,2)" << endl;
  Edge* e11 = Graf2.SelectEdge(1,2);

  cout << "v0 dla e: " << e11->V0()->Number() << endl;
  cout << "v1 dla e: " << e11->V1()->Number() << endl;

  cout << "Sasiad (v0) dla e: " << e11->Mate(e11->V0())->Number() << endl;
  cout << "Sasiad (v1) dla e: " << e11->Mate(e11->V1())->Number() << endl;

  e11->weight = e11->V0()->Number() + e11->V1()->Number();
  cout << "Waga krawedzi e: " << e11->weight << endl;
  cout << endl;

  // Krawedz (2,3)
  cout << "Krawedz (2,3)" << endl;
  Edge* e22 = Graf2.SelectEdge(2,3);

  cout << "v0 dla e: " << e22->V0()->Number() << endl;
  cout << "v1 dla e: " << e22->V1()->Number() << endl;

  cout << "Sasiad (v0) dla e: " << e22->Mate(e22->V0())->Number() << endl;
  cout << "Sasiad (v1) dla e: " << e22->Mate(e22->V1())->Number() << endl;

  e22->weight = e22->V0()->Number() + e22->V1()->Number();
  cout << "Waga krawedzi e: " << e22->weight << endl;
  cout << endl;

  // Krawedz (3,4)
  cout << "Krawedz (3,4)" << endl;
  Edge* e33 = Graf2.SelectEdge(3,4);

  cout << "v0 dla e: " << e33->V0()->Number() << endl;
  cout << "v1 dla e: " << e33->V1()->Number() << endl;

  cout << "Sasiad (v0) dla e: " << e33->Mate(e33->V0())->Number() << endl;
  cout << "Sasiad (v1) dla e: " << e33->Mate(e33->V1())->Number() << endl;

  e33->weight = e33->V0()->Number() + e33->V1()->Number();
  cout << "Waga krawedzi e: " << e3->weight << endl;
  cout << endl;

  // Krawedz (9,9)
  cout << "Krawedz (9,9)" << endl;
  Edge* e44 = Graf2.SelectEdge(9,9);

  cout << "v0 dla e: " << e44->V0()->Number() << endl;
  cout << "v1 dla e: " << e44->V1()->Number() << endl;

  cout << "Sasiad (v0) dla e: " << e44->Mate(e44->V0())->Number() << endl;
  cout << "Sasiad (v1) dla e: " << e44->Mate(e44->V1())->Number() << endl;

  e44->weight = e44->V0()->Number() + e44->V1()->Number();
  cout << "Waga krawedzi e: " << e44->weight << endl;
  cout << endl;






  return 0;
}