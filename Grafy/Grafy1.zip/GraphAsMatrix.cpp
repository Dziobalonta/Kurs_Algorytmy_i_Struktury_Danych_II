#include <iostream>
#include <vector>
#include "GraphAsMatrix.h"

GraphAsMatrix::GraphAsMatrix(int n, bool b): numberOfVertices(n), isDirected(b), vertices(n)
{
  for (int i = 0; i < n; i++)
  {
    vertices[i] = new Vertex(i);
  }

  adjacencyMatrix.resize(n, std::vector<Edge *>(n, nullptr));
}

bool GraphAsMatrix::IsEdge(int u, int v)
{
  // return (u > 0 && u < numberOfVertices && v > 0 && v < numberOfVertices);
  return (adjacencyMatrix[u][v] != nullptr);
}

void GraphAsMatrix::MakeNull() 
{
  //Krawedzie
  for(auto &row : adjacencyMatrix) 
  {
    for(auto &edge : row) 
    {
      delete edge;
      edge = nullptr; // dla pewnosci
    }
  }
  numberOfEdges = 0;

  //Wierzcholki
  for (auto &vertex: vertices)
  {
    delete vertex;
    vertex = nullptr; // dla pewnosci
  }
}


void GraphAsMatrix::AddEdge(int u, int v)
{
  if(u > 0 && u < numberOfVertices && v > 0 && v < numberOfVertices)
  {
    Edge* krawedz = new Edge(vertices[u],vertices[v]);
    if (adjacencyMatrix[u][v] == nullptr)
    {
      adjacencyMatrix[u][v] = krawedz;
      numberOfEdges++;
    }

    // Przypadek gdy jest nieskierowany - "duplikujemy wartosc" po drugiej stronie macierzy
    if (!isDirected)
    {
      adjacencyMatrix[v][u] = krawedz;
      numberOfEdges++;
    }
  }
}

Edge* GraphAsMatrix::SelectEdge (int u, int v)
{
    if(u > 0 && u < numberOfVertices && v > 0 && v < numberOfVertices) 
      return adjacencyMatrix[u][v];
    else 
      return nullptr;
}

Vertex* GraphAsMatrix::SelectVertex(int v)
{
  if(v >= 0 && v < numberOfVertices) return vertices[v];
  else throw std::out_of_range("Vertex index is out of range");
}